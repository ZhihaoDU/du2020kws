# Honk models
`google-speech-dataset.pt`: model for discriminating keywords `__silence__`, `__unknown__`, yes, no, up, down, left, right, on, off, stop, go. Best dev accuracy: 88.5%.

